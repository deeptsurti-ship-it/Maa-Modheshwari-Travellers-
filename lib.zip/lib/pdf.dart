import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:intl/intl.dart';
import 'package:open_file/open_file.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:cloud_firestore/cloud_firestore.dart';

// Save invoice data to Firestore (text only)
Future<void> saveInvoiceToFirestore({
  required String customerName,
  required String tripDetails,
  required String vehicleType,
  required String rate,
  required String amount,
  required String date,
  required bool isAuto,
  required String days,
  required String address,
  required String KM,
  required String extra,
  required String dateDetails,
}) async {
  await FirebaseFirestore.instance.collection('invoices_text_only').add({
    'customerName': customerName,
    'tripDetails': tripDetails,
    'vehicleType': vehicleType,
    'rate': rate,
    'amount': amount,
    'isAuto': isAuto,
    'date': date,
    'days': days,
    'address': address,
    'extra': extra,
    'KM': KM,
    'dateDetails': dateDetails,
    'timestamp': Timestamp.now(),
  });
}

Future<void> generateInvoicePdf({
  required BuildContext context,
  required String customerName,
  required String tripDetails,
  required String vehicleType,
  required String rate,
  required String amount,
  required String date,
  required bool isAuto,
  required String days,
  required String address,
  required String KM,
  required String extra,
  required String dateDetails,
}) async {
  try {
    // 🧹 1. Delete all old PDFs from app folder
    final outputDir = await getApplicationDocumentsDirectory();
    final files = outputDir.listSync();
    for (var file in files) {
      if (file is File && file.path.endsWith('.pdf')) {
        await file.delete();
      }
    }

    // 🧾 2. Generate new PDF
    final pdf = pw.Document();
    final fontData = await rootBundle.load("assets/fonts/NotoSans-Regular.ttf");
    final customFont = pw.Font.ttf(fontData);
    final logoData = await rootBundle.load("assets/logo.jpeg");
    final logoImage = pw.MemoryImage(logoData.buffer.asUint8List());

    final totalAmount = isAuto
        ? (double.tryParse(rate) ?? 0) * (double.tryParse(KM) ?? 1)
        : double.tryParse(amount) ?? 0;

    pdf.addPage(
      pw.Page(
        theme: pw.ThemeData.withFont(base: customFont),
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(24),
        build: (context) {
          return pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Row(
                mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                children: [
                  pw.Image(logoImage, width: 80),
                  pw.Column(
                    crossAxisAlignment: pw.CrossAxisAlignment.end,
                    children: [
                      pw.Text("Maa Modheshwari Travels",
                          style: pw.TextStyle(fontSize: 22, fontWeight: pw.FontWeight.bold)),
                      pw.SizedBox(height: 4),
                      pw.Text(
                        "2/A, Raghuvir Society, Opp. Old Bombay Market,\nBombay Market Rd, Umarwada, Surat-395010",
                        textAlign: pw.TextAlign.right,
                        style: const pw.TextStyle(fontSize: 9),
                      ),
                      pw.SizedBox(height: 4),
                      pw.Text("Dipakbhai: 9624742600", style: const pw.TextStyle(fontSize: 10)),
                      pw.Text("Sanjaybhai: 9624742800", style: const pw.TextStyle(fontSize: 10)),
                    ],
                  ),
                ],
              ),
              pw.SizedBox(height: 16),
              pw.Center(
                child: pw.Text("INVOICE",
                    style: pw.TextStyle(fontSize: 22, fontWeight: pw.FontWeight.bold)),
              ),
              pw.SizedBox(height: 20),
              pw.Table(
                columnWidths: {
                  0: const pw.FlexColumnWidth(3),
                  1: const pw.FlexColumnWidth(6),
                },
                border: pw.TableBorder.all(color: PdfColors.grey),
                children: [
                  tableRow("Invoice Date", date),
                  tableRow("Customer Name", customerName),
                  tableRow("Customer Address", address),
                  tableRow("Trip", tripDetails),
                  tableRow("Date", dateDetails),
                  tableRow("Vehicle Type", vehicleType),
                  tableRow("Rate", "₹ $rate"),
                  tableRow("KM", KM),
                  tableRow("Days", days),
                  tableRow("Extra", extra),
                  if (!isAuto) tableRow("Amount", "₹ $amount"),
                  if (isAuto) tableRow("Amount", "₹ ${totalAmount.toStringAsFixed(2)}"),
                ],
              ),
              pw.Spacer(),
              pw.Divider(),
              pw.Center(
                child: pw.Column(
                  children: [
                    pw.Text("For any help contact: 9624742600 / 800",
                        style: const pw.TextStyle(fontSize: 10)),
                    pw.SizedBox(height: 4),
                    pw.Text("Thank you for choosing Maa Modheshwari Travels!",
                        style: const pw.TextStyle(fontSize: 11)),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );

    // 💾 3. Save new PDF
    String formattedDate = DateFormat('dd-MMM-yyyy_ss').format(DateTime.now());
    String toLocation = tripDetails.split("To:").last.trim();
    String fileName = '$formattedDate - $toLocation - $vehicleType.pdf';
    final filePath = "${outputDir.path}/$fileName";
    final file = File(filePath);
    await file.writeAsBytes(await pdf.save());

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("✅ PDF created & old files deleted")),
    );

    await OpenFile.open(file.path);
  } catch (e) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("PDF generation failed: $e")),
    );
  }
}

pw.TableRow tableRow(String label, String value) {
  return pw.TableRow(
    children: [
      pw.Container(
        padding: const pw.EdgeInsets.all(8),
        child: pw.Text(label, style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
      ),
      pw.Container(
        padding: const pw.EdgeInsets.all(8),
        child: pw.Text(value),
      ),
    ],
  );
}
