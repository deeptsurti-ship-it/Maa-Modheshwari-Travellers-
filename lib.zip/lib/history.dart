import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:travel_bill/pdf.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  String searchQuery = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Invoice History'),
        centerTitle: true,
        backgroundColor: Colors.deepPurple,
        actions: [
          PopupMenuButton<String>(
            onSelected: (value) async {
              if (value == 'delete_all') {
                final confirm = await showDialog<bool>(
                  context: context,
                  builder: (context) => AlertDialog(
                    title: const Text("Confirm Deletion"),
                    content: const Text("Are you sure you want to delete all invoices?"),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.of(context).pop(false),
                        child: const Text("Cancel"),
                      ),
                      TextButton(
                        onPressed: () async {
                          await deleteAllInvoices();
                          Navigator.of(context).pop(true);
                        },
                        child: const Text("Delete All"),
                      ),
                    ],
                  ),
                );

                if (confirm == true) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text("✅ All invoices deleted")),
                  );
                }
              }
            },
            itemBuilder: (context) => [
              const PopupMenuItem(
                value: 'delete_all',
                child: Text('Delete All'),
              ),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              decoration: const InputDecoration(
                labelText: 'Search (e.g. date:27-06 vehicle:innova)',
                prefixIcon: Icon(Icons.search),
              ),
              onChanged: (value) {
                setState(() {
                  searchQuery = value.toLowerCase();
                });
              },
            ),
          ),
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('invoices_text_only')
                  .orderBy('timestamp', descending: true)
                  .snapshots(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                  return const Center(child: Text('No invoices found.'));
                }

                final terms = searchQuery.split(' ').where((t) => t.isNotEmpty).toList();

                final invoices = snapshot.data!.docs.where((doc) {
                  final data = {
                    'customer': doc['customerName']?.toString().toLowerCase() ?? '',
                    'trip': doc['tripDetails']?.toString().toLowerCase() ?? '',
                    'date': doc['date']?.toString().toLowerCase() ?? '',
                    'vehicle': doc['vehicleType']?.toString().toLowerCase() ?? '',
                  };

                  return terms.every((term) {
                    if (term.contains(':')) {
                      final parts = term.split(':');
                      if (parts.length != 2) return false;
                      final key = parts[0], val = parts[1];
                      return data[key]?.contains(val) ?? false;
                    } else {
                      return data.values.any((value) => value.contains(term));
                    }
                  });
                }).toList();

                return ListView.builder(
                  itemCount: invoices.length,
                  itemBuilder: (context, index) {
                    final doc = invoices[index];
                    final timestamp = (doc['timestamp'] as Timestamp).toDate();
                    final formattedDate = DateFormat('dd-MM-yyyy').format(timestamp);

                    return Card(
                      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      child: ListTile(
                        title: highlightText(doc['tripDetails'] ?? 'ETC', terms),
                        subtitle: highlightText("Date: ${doc['date'] ?? formattedDate} , Vehicle: ${doc['vehicleType'] ?? 'ETC'}", terms),
                        trailing: PopupMenuButton<String>(
                          onSelected: (value) async {
                            if (value == 'export') {
                              await generateInvoicePdf(
                                context: context,
                                customerName: doc['customerName'],
                                tripDetails: doc['tripDetails'],
                                vehicleType: doc['vehicleType'],
                                rate: doc['rate'],
                                amount: doc['amount'],
                                date: doc['date'],
                                isAuto: doc['isAuto'],
                                days: doc['days'],
                                address: doc['address'],
                                KM: doc['KM'],
                                extra: doc['extra'],
                                dateDetails: doc['dateDetails'],
                              );
                            } else if (value == 'delete') {
                              await doc.reference.delete();
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(content: Text("Invoice deleted")),
                              );
                            }
                          },
                          itemBuilder: (context) => [
                            const PopupMenuItem(
                              value: 'export',
                              child: Text('Export to PDF'),
                            ),
                            const PopupMenuItem(
                              value: 'delete',
                              child: Text('Delete'),
                            ),
                          ],
                        ),
                        onTap: () {
                          showDialog(
                            context: context,
                            builder: (_) => AlertDialog(
                              title: const Text("Invoice Details"),
                              content: SingleChildScrollView(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: (doc.data() as Map<String, dynamic>)
                                      .entries
                                      .map((e) => Padding(
                                    padding: const EdgeInsets.only(bottom: 4),
                                    child: Text("${e.key}: ${e.value}"),
                                  ))
                                      .toList(),
                                ),
                              ),
                              actions: [
                                TextButton(
                                  child: const Text("Close"),
                                  onPressed: () => Navigator.of(context).pop(),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget highlightText(String source, List<String> terms) {
    final spans = <TextSpan>[];
    String remaining = source;
    while (remaining.isNotEmpty) {
      final match = terms.firstWhere(
            (term) => remaining.toLowerCase().contains(term),
        orElse: () => '',
      );
      if (match.isEmpty) {
        spans.add(TextSpan(text: remaining));
        break;
      }
      final index = remaining.toLowerCase().indexOf(match);
      if (index > 0) {
        spans.add(TextSpan(text: remaining.substring(0, index)));
      }
      spans.add(TextSpan(
        text: remaining.substring(index, index + match.length),
        style: const TextStyle(backgroundColor: Colors.yellow),
      ));
      remaining = remaining.substring(index + match.length);
    }
    return RichText(
      text: TextSpan(style: const TextStyle(color: Colors.black), children: spans),
    );
  }

  Future<void> deleteAllInvoices() async {
    final collection = FirebaseFirestore.instance.collection('invoices_text_only');
    final snapshot = await collection.get();
    for (final doc in snapshot.docs) {
      await doc.reference.delete();
    }
  }
}
