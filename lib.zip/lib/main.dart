import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:travel_bill/history.dart';
import 'package:travel_bill/pdf.dart';
import 'splash_screen.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const InvoiceApp());
}

class InvoiceApp extends StatelessWidget {
  const InvoiceApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Maa Modheshwari Travels',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Poppins',
        scaffoldBackgroundColor: const Color(0xFFF6F8FA),
        inputDecorationTheme: InputDecorationTheme(
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(20),
            borderSide: const BorderSide(color: Colors.deepPurpleAccent),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(20),
            borderSide: const BorderSide(color: Colors.deepPurpleAccent),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(20),
            borderSide: const BorderSide(color: Colors.deepPurple, width: 2),
          ),
          filled: true,
          fillColor: Colors.white,
          prefixIconColor: Colors.deepPurple,
          labelStyle: GoogleFonts.poppins(fontWeight: FontWeight.w500),
        ),
        textTheme: GoogleFonts.poppinsTextTheme(),
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        appBarTheme: const AppBarTheme(
          elevation: 6,
          backgroundColor: Colors.deepPurple,
          foregroundColor: Colors.white,
          centerTitle: true,
          titleTextStyle: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.w600,
            color: Colors.white,
          ),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
            backgroundColor: Colors.deepPurple,
            foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            textStyle: GoogleFonts.poppins(
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
            elevation: 10,
            shadowColor: Colors.deepPurple.shade100,
          ),
        ),
      ),
      home: const SplashScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class InvoiceScreen extends StatefulWidget {
  const InvoiceScreen({super.key});

  @override
  State<InvoiceScreen> createState() => _InvoiceScreenState();
}

class _InvoiceScreenState extends State<InvoiceScreen> {
  final _formKey = GlobalKey<FormState>();

  final dateController = TextEditingController();
  final nameController = TextEditingController();
  final fromController = TextEditingController();
  final toController = TextEditingController();
  final vehicleController = TextEditingController();
  final rateController = TextEditingController();
  final amountController = TextEditingController();
  final daysController = TextEditingController();
  final addsController = TextEditingController();
  final kmController = TextEditingController();
  final extraController = TextEditingController();
  final fromDateController = TextEditingController();
  final toDateController = TextEditingController();

  bool isAuto = false;

  @override
  void dispose() {
    dateController.dispose();
    nameController.dispose();
    fromController.dispose();
    toController.dispose();
    vehicleController.dispose();
    rateController.dispose();
    amountController.dispose();
    daysController.dispose();
    addsController.dispose();
    kmController.dispose();
    extraController.dispose();
    fromDateController.dispose();
    toDateController.dispose();
    super.dispose();
  }

  void generatePDF() async {
    final tripDetails = "From: ${fromController.text}   To: ${toController.text}";
    final dateDetails = "From: ${fromDateController.text}   To: ${toDateController.text}";
    final days = daysController.text;

    if (dateController.text.trim().isEmpty) {
      dateController.text = DateFormat('dd-MM-yyyy').format(DateTime.now());
    }

    await generateInvoicePdf(
      context: context,
      date: dateController.text,
      customerName: nameController.text,
      address: addsController.text,
      tripDetails: tripDetails,
      dateDetails: dateDetails,
      vehicleType: vehicleController.text,
      rate: rateController.text,
      KM: kmController.text,
      extra: extraController.text,
      amount: amountController.text,
      isAuto: isAuto,
      days: days,
    );

    await saveInvoiceToFirestore(
      customerName: nameController.text,
      tripDetails: tripDetails,
      vehicleType: vehicleController.text,
      rate: rateController.text,
      amount: amountController.text,
      date: dateController.text,
      isAuto: isAuto,
      days: days,
      address: addsController.text,
      KM: kmController.text,
      extra: extraController.text,
      dateDetails: dateDetails,
    );

    setState(() {
      dateController.clear();
      nameController.clear();
      fromController.clear();
      toController.clear();
      fromDateController.clear();
      toDateController.clear();
      vehicleController.clear();
      rateController.clear();
      kmController.clear();
      daysController.clear();
      extraController.clear();
      amountController.clear();
      addsController.clear();
      isAuto = false;
    });
  }

  DateTime? _parseDate(String dateStr) {
    try {
      return DateFormat('dd-MM-yyyy').parse(dateStr);
    } catch (_) {
      return null;
    }
  }

  void showFancySnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const Icon(Icons.warning_amber_rounded, color: Colors.white),
            const SizedBox(width: 12),
            Expanded(child: Text(message)),
          ],
        ),
        backgroundColor: Colors.redAccent,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  // Submit button bounce animation + maxx UI polish 💎

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        extendBodyBehindAppBar: true,
        appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text(
        "Maa Modheshwari Travels",
        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20, color: Colors.white),
    ),
    centerTitle: true,
    actions: [
    IconButton(
    icon: const Icon(Icons.history, color: Colors.white),
    tooltip: 'Invoice History',
    onPressed: () {
    Navigator.push(
    context,
    MaterialPageRoute(builder: (_) => const HistoryScreen()),
    );
    },
    ),
    ],
    ),
    body: Container(
    decoration: const BoxDecoration(
    gradient: LinearGradient(
    colors: [Color(0xFF6A11CB), Color(0xFF2575FC)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    ),
    ),
    child: SafeArea(
    child: SingleChildScrollView(
    padding: const EdgeInsets.all(16),
    child: TweenAnimationBuilder(
    duration: const Duration(milliseconds: 800),
    curve: Curves.easeOutExpo,
    tween: Tween<double>(begin: 0.9, end: 1.0),
    builder: (context, value, child) => Transform.scale(
    scale: value,
    child: child,
    ),
    child: Container(
    decoration: BoxDecoration(
    color: Colors.white,
    borderRadius: BorderRadius.circular(32),
    boxShadow: [
    BoxShadow(
    color: Colors.black.withOpacity(0.08),
    blurRadius: 24,
    offset: const Offset(0, 8),
    ),
    ],
    ),
    child: Padding(
    padding: const EdgeInsets.all(24),
    child: Form(
    key: _formKey,
    child: Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
    Center(
    child: Text(
    "🧾 Create Invoice",
    style: Theme.of(context).textTheme.headlineSmall!.copyWith(
    fontWeight: FontWeight.bold,
    color: Colors.deepPurple.shade700,
    ),
    ),
    ),
    const SizedBox(height: 24),
    buildFancyDateField("Invoice Date", dateController, errorText: "Select invoice date"),
    buildFancyTextField("Customer Name", nameController, Icons.person, "Enter customer name"),
    buildFancyTextField("Address", addsController, Icons.home, "Enter address"),
    buildFancyTextField("From", fromController, Icons.location_on, "Enter starting point"),
    buildFancyTextField("To", toController, Icons.flag, "Enter destination"),
    buildFancyDateField("From Date", fromDateController, errorText: "Select from date"),
    buildFancyDateField("To Date", toDateController, errorText: "Select to date"),
    buildFancyTextField("Vehicle Type", vehicleController, Icons.directions_car, "Enter vehicle"),
    buildFancyTextField("Rate (₹)", rateController, Icons.currency_rupee, "Enter rate", inputType: TextInputType.number),
    buildFancyTextField("KM (₹)", kmController, Icons.directions_walk, "Enter KM", inputType: TextInputType.number),
    buildFancyTextField("Days", daysController, Icons.calendar_today, "Enter number of days", inputType: TextInputType.number),
    buildFancyTextField("Extra", extraController, Icons.add, "Enter extra or 0"),
    const SizedBox(height: 18),
    Container(
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(
    borderRadius: BorderRadius.circular(16),
    color: Colors.deepPurple.shade50,
    ),
    child: Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
    Text(
    "Calculation Mode",
    style: Theme.of(context).textTheme.titleMedium!.copyWith(fontWeight: FontWeight.w600),
    ),
    const SizedBox(height: 6),
      Row(
        children: [
          Expanded(
            child: RadioListTile<bool>(
              contentPadding: EdgeInsets.zero,
              visualDensity: VisualDensity(horizontal: -4, vertical: -4),
              title: const Text("Manual", overflow: TextOverflow.ellipsis), // prevent wrapping
              // visualDensity: VisualDensity.compact, // tighter layout
              dense: true,
              value: false,
              groupValue: isAuto,
              onChanged: (value) => setState(() => isAuto = value!),
            ),
          ),
          Expanded(
            child: RadioListTile<bool>(
              title: const Text("Auto", overflow: TextOverflow.ellipsis),
              visualDensity: VisualDensity.compact,
              dense: true,
              value: true,
              groupValue: isAuto,
              onChanged: (value) => setState(() => isAuto = value!),
            ),
          ),
        ],
      ),

    ],
    ),
    ),
    const SizedBox(height: 30),

      if (!isAuto)
        buildFancyTextField("Amount (₹)", amountController, Icons.currency_rupee_outlined, "Enter amount", inputType: TextInputType.number),

    Center(
    child: TweenAnimationBuilder<double>(
    tween: Tween<double>(begin: 0.95, end: 1.0),
    curve: Curves.elasticOut,
    duration: const Duration(milliseconds: 800),
    builder: (context, scale, child) {
    return Transform.scale(
    scale: scale,
    child: ElevatedButton.icon(
    onPressed: () {
    HapticFeedback.lightImpact();
    if (_formKey.currentState?.validate() ?? false) {
    final fromDate = _parseDate(fromDateController.text);
    final toDate = _parseDate(toDateController.text);

    if (fromDate != null && toDate != null && fromDate.isAfter(toDate)) {
    showFancySnackBar("❌ To Date cannot be before From Date");
    return;
    }

    final invoiceDate = _parseDate(dateController.text);

    if (invoiceDate != null && fromDate != null && invoiceDate.isAfter(fromDate)) {
      showFancySnackBar("❌ Invoice Date cannot be after From Date");
      return;
    }

    generatePDF();
    }
    },
    icon: const Icon(Icons.picture_as_pdf),
    label: const Text("Generate Invoice PDF"),
    style: ElevatedButton.styleFrom(
    backgroundColor: Colors.deepPurple,
    foregroundColor: Colors.white,
    padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 16),
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
    elevation: 20,
    shadowColor: Colors.deepPurple.shade200,
    ),
    ),
    );
    },
    ),
    ),
    const SizedBox(height: 16),
    ],
    ),
    ),
    ),
    ),
    ),
    ),
    ),
    ),
    );
  }

  Widget buildFancyTextField(String label, TextEditingController controller, IconData icon, String errorText, {TextInputType inputType = TextInputType.text}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          gradient: const LinearGradient(
            colors: [Color(0xFFF3F2FF), Color(0xFFEDE7F6)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.deepPurple.withOpacity(0.1),
              blurRadius: 10,
              offset: const Offset(0, 4),
            )
          ],
        ),
        child: TextFormField(
          controller: controller,
          keyboardType: inputType,
          decoration: InputDecoration(
            labelText: label,
            prefixIcon: Icon(icon),
            filled: true,
            fillColor: Colors.white,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
          ),
          validator: (value) => (value == null || value.trim().isEmpty) ? errorText : null,
        ),
      ),
    );
  }

  Widget buildFancyDateField(String label, TextEditingController controller, {required String errorText}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          gradient: const LinearGradient(
            colors: [Color(0xFFFFF8E1), Color(0xFFFFECB3)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.orange.withOpacity(0.1),
              blurRadius: 10,
              offset: const Offset(0, 4),
            )
          ],
        ),
        child: TextFormField(
          controller: controller,
          readOnly: true,
          onTap: () => _selectDate(controller),
          decoration: InputDecoration(
            labelText: label,
            prefixIcon: const Icon(Icons.calendar_today),
            filled: true,
            fillColor: Colors.white,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
          ),
          validator: (value) => (value == null || value.trim().isEmpty) ? errorText : null,
        ),
      ),
    );
  }

  Future<void> _selectDate(TextEditingController controller) async {
    DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
    );

    if (picked != null) {
      String formatted = DateFormat('dd-MM-yyyy').format(picked);
      setState(() => controller.text = formatted);
    }
  }
}
