package com.example.travel_bill

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
